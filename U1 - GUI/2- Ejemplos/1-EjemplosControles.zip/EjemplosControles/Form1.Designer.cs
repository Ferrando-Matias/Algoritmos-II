﻿namespace EjemplosControles
{
    partial class FrmControles
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtEjemplo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.chkEjemplo = new System.Windows.Forms.CheckBox();
            this.grpEjemplo = new System.Windows.Forms.GroupBox();
            this.rdbEjemplo1 = new System.Windows.Forms.RadioButton();
            this.rdbEjemplo2 = new System.Windows.Forms.RadioButton();
            this.rdbEjemplo3 = new System.Windows.Forms.RadioButton();
            this.lstEjemplo = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbEjemplo = new System.Windows.Forms.ComboBox();
            this.chlbEjemplo = new System.Windows.Forms.CheckedListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dtpFechaEjemplo = new System.Windows.Forms.DateTimePicker();
            this.btnVerTxt = new System.Windows.Forms.Button();
            this.btnVerChk = new System.Windows.Forms.Button();
            this.btnVerRdb = new System.Windows.Forms.Button();
            this.btnVerLst = new System.Windows.Forms.Button();
            this.btnVerCmb = new System.Windows.Forms.Button();
            this.btnVerChlb = new System.Windows.Forms.Button();
            this.btnVerDtp = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.nmrEjemplo = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.mskEjemplo = new System.Windows.Forms.MaskedTextBox();
            this.btnVerNmr = new System.Windows.Forms.Button();
            this.btnVerMsk = new System.Windows.Forms.Button();
            this.grpEjemplo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmrEjemplo)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(270, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Controles Windows Forms";
            // 
            // txtEjemplo
            // 
            this.txtEjemplo.Location = new System.Drawing.Point(74, 46);
            this.txtEjemplo.Name = "txtEjemplo";
            this.txtEjemplo.Size = new System.Drawing.Size(149, 20);
            this.txtEjemplo.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "TextBox:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "CheckBox:";
            // 
            // chkEjemplo
            // 
            this.chkEjemplo.AutoSize = true;
            this.chkEjemplo.Location = new System.Drawing.Point(76, 139);
            this.chkEjemplo.Name = "chkEjemplo";
            this.chkEjemplo.Size = new System.Drawing.Size(115, 17);
            this.chkEjemplo.TabIndex = 10;
            this.chkEjemplo.Text = "CheckBox Ejemplo";
            this.chkEjemplo.UseVisualStyleBackColor = true;
            // 
            // grpEjemplo
            // 
            this.grpEjemplo.Controls.Add(this.rdbEjemplo3);
            this.grpEjemplo.Controls.Add(this.rdbEjemplo2);
            this.grpEjemplo.Controls.Add(this.rdbEjemplo1);
            this.grpEjemplo.Location = new System.Drawing.Point(15, 168);
            this.grpEjemplo.Name = "grpEjemplo";
            this.grpEjemplo.Size = new System.Drawing.Size(211, 100);
            this.grpEjemplo.TabIndex = 12;
            this.grpEjemplo.TabStop = false;
            this.grpEjemplo.Text = "GroupBox Ejemplo";
            // 
            // rdbEjemplo1
            // 
            this.rdbEjemplo1.AutoSize = true;
            this.rdbEjemplo1.Location = new System.Drawing.Point(7, 20);
            this.rdbEjemplo1.Name = "rdbEjemplo1";
            this.rdbEjemplo1.Size = new System.Drawing.Size(133, 17);
            this.rdbEjemplo1.TabIndex = 13;
            this.rdbEjemplo1.TabStop = true;
            this.rdbEjemplo1.Text = "RadioButton Ejemplo 1";
            this.rdbEjemplo1.UseVisualStyleBackColor = true;
            // 
            // rdbEjemplo2
            // 
            this.rdbEjemplo2.AutoSize = true;
            this.rdbEjemplo2.Location = new System.Drawing.Point(7, 44);
            this.rdbEjemplo2.Name = "rdbEjemplo2";
            this.rdbEjemplo2.Size = new System.Drawing.Size(133, 17);
            this.rdbEjemplo2.TabIndex = 14;
            this.rdbEjemplo2.TabStop = true;
            this.rdbEjemplo2.Text = "RadioButton Ejemplo 2";
            this.rdbEjemplo2.UseVisualStyleBackColor = true;
            // 
            // rdbEjemplo3
            // 
            this.rdbEjemplo3.AutoSize = true;
            this.rdbEjemplo3.Location = new System.Drawing.Point(7, 68);
            this.rdbEjemplo3.Name = "rdbEjemplo3";
            this.rdbEjemplo3.Size = new System.Drawing.Size(133, 17);
            this.rdbEjemplo3.TabIndex = 15;
            this.rdbEjemplo3.TabStop = true;
            this.rdbEjemplo3.Text = "RadioButton Ejemplo 3";
            this.rdbEjemplo3.UseVisualStyleBackColor = true;
            // 
            // lstEjemplo
            // 
            this.lstEjemplo.FormattingEnabled = true;
            this.lstEjemplo.Location = new System.Drawing.Point(15, 293);
            this.lstEjemplo.Name = "lstEjemplo";
            this.lstEjemplo.Size = new System.Drawing.Size(211, 95);
            this.lstEjemplo.TabIndex = 18;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 277);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "ListBox Ejemplo";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 396);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "ComboBox Ejemplo";
            // 
            // cmbEjemplo
            // 
            this.cmbEjemplo.FormattingEnabled = true;
            this.cmbEjemplo.Location = new System.Drawing.Point(15, 412);
            this.cmbEjemplo.Name = "cmbEjemplo";
            this.cmbEjemplo.Size = new System.Drawing.Size(211, 21);
            this.cmbEjemplo.TabIndex = 21;
            // 
            // chlbEjemplo
            // 
            this.chlbEjemplo.CheckOnClick = true;
            this.chlbEjemplo.FormattingEnabled = true;
            this.chlbEjemplo.Location = new System.Drawing.Point(15, 457);
            this.chlbEjemplo.Name = "chlbEjemplo";
            this.chlbEjemplo.Size = new System.Drawing.Size(211, 94);
            this.chlbEjemplo.TabIndex = 24;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 441);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "CheckedListBox Ejemplo";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 558);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "DateTimePicker Ejemplo";
            // 
            // dtpFechaEjemplo
            // 
            this.dtpFechaEjemplo.Location = new System.Drawing.Point(15, 575);
            this.dtpFechaEjemplo.Name = "dtpFechaEjemplo";
            this.dtpFechaEjemplo.Size = new System.Drawing.Size(211, 20);
            this.dtpFechaEjemplo.TabIndex = 27;
            // 
            // btnVerTxt
            // 
            this.btnVerTxt.Location = new System.Drawing.Point(233, 44);
            this.btnVerTxt.Name = "btnVerTxt";
            this.btnVerTxt.Size = new System.Drawing.Size(75, 23);
            this.btnVerTxt.TabIndex = 2;
            this.btnVerTxt.Text = "Visualizar";
            this.btnVerTxt.UseVisualStyleBackColor = true;
            this.btnVerTxt.Click += new System.EventHandler(this.btnVerTxt_Click);
            // 
            // btnVerChk
            // 
            this.btnVerChk.Location = new System.Drawing.Point(233, 135);
            this.btnVerChk.Name = "btnVerChk";
            this.btnVerChk.Size = new System.Drawing.Size(75, 23);
            this.btnVerChk.TabIndex = 11;
            this.btnVerChk.Text = "Visualizar";
            this.btnVerChk.UseVisualStyleBackColor = true;
            this.btnVerChk.Click += new System.EventHandler(this.btnVerChk_Click);
            // 
            // btnVerRdb
            // 
            this.btnVerRdb.Location = new System.Drawing.Point(232, 209);
            this.btnVerRdb.Name = "btnVerRdb";
            this.btnVerRdb.Size = new System.Drawing.Size(75, 23);
            this.btnVerRdb.TabIndex = 16;
            this.btnVerRdb.Text = "Visualizar";
            this.btnVerRdb.UseVisualStyleBackColor = true;
            this.btnVerRdb.Click += new System.EventHandler(this.btnVerRdb_Click);
            // 
            // btnVerLst
            // 
            this.btnVerLst.Location = new System.Drawing.Point(232, 329);
            this.btnVerLst.Name = "btnVerLst";
            this.btnVerLst.Size = new System.Drawing.Size(75, 23);
            this.btnVerLst.TabIndex = 19;
            this.btnVerLst.Text = "Visualizar";
            this.btnVerLst.UseVisualStyleBackColor = true;
            this.btnVerLst.Click += new System.EventHandler(this.btnVerLst_Click);
            // 
            // btnVerCmb
            // 
            this.btnVerCmb.Location = new System.Drawing.Point(233, 409);
            this.btnVerCmb.Name = "btnVerCmb";
            this.btnVerCmb.Size = new System.Drawing.Size(75, 23);
            this.btnVerCmb.TabIndex = 22;
            this.btnVerCmb.Text = "Visualizar";
            this.btnVerCmb.UseVisualStyleBackColor = true;
            this.btnVerCmb.Click += new System.EventHandler(this.btnVerCmb_Click);
            // 
            // btnVerChlb
            // 
            this.btnVerChlb.Location = new System.Drawing.Point(232, 494);
            this.btnVerChlb.Name = "btnVerChlb";
            this.btnVerChlb.Size = new System.Drawing.Size(75, 23);
            this.btnVerChlb.TabIndex = 25;
            this.btnVerChlb.Text = "Visualizar";
            this.btnVerChlb.UseVisualStyleBackColor = true;
            this.btnVerChlb.Click += new System.EventHandler(this.btnVerChlb_Click);
            // 
            // btnVerDtp
            // 
            this.btnVerDtp.Location = new System.Drawing.Point(232, 572);
            this.btnVerDtp.Name = "btnVerDtp";
            this.btnVerDtp.Size = new System.Drawing.Size(75, 23);
            this.btnVerDtp.TabIndex = 28;
            this.btnVerDtp.Text = "Visualizar";
            this.btnVerDtp.UseVisualStyleBackColor = true;
            this.btnVerDtp.Click += new System.EventHandler(this.btnVerDtp_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 78);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "NumericUpDown:";
            // 
            // nmrEjemplo
            // 
            this.nmrEjemplo.Location = new System.Drawing.Point(110, 76);
            this.nmrEjemplo.Name = "nmrEjemplo";
            this.nmrEjemplo.Size = new System.Drawing.Size(113, 20);
            this.nmrEjemplo.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 106);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "MaskedTextBox:";
            // 
            // mskEjemplo
            // 
            this.mskEjemplo.Location = new System.Drawing.Point(110, 103);
            this.mskEjemplo.Mask = "(9999)00-0000-0000";
            this.mskEjemplo.Name = "mskEjemplo";
            this.mskEjemplo.Size = new System.Drawing.Size(113, 20);
            this.mskEjemplo.TabIndex = 7;
            // 
            // btnVerNmr
            // 
            this.btnVerNmr.Location = new System.Drawing.Point(233, 73);
            this.btnVerNmr.Name = "btnVerNmr";
            this.btnVerNmr.Size = new System.Drawing.Size(75, 23);
            this.btnVerNmr.TabIndex = 5;
            this.btnVerNmr.Text = "Visualizar";
            this.btnVerNmr.UseVisualStyleBackColor = true;
            this.btnVerNmr.Click += new System.EventHandler(this.btnVerNmr_Click);
            // 
            // btnVerMsk
            // 
            this.btnVerMsk.Location = new System.Drawing.Point(233, 101);
            this.btnVerMsk.Name = "btnVerMsk";
            this.btnVerMsk.Size = new System.Drawing.Size(75, 23);
            this.btnVerMsk.TabIndex = 8;
            this.btnVerMsk.Text = "Visualizar";
            this.btnVerMsk.UseVisualStyleBackColor = true;
            this.btnVerMsk.Click += new System.EventHandler(this.btnVerMsk_Click);
            // 
            // FrmControles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(330, 624);
            this.Controls.Add(this.btnVerMsk);
            this.Controls.Add(this.btnVerNmr);
            this.Controls.Add(this.mskEjemplo);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.nmrEjemplo);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnVerDtp);
            this.Controls.Add(this.btnVerChlb);
            this.Controls.Add(this.btnVerCmb);
            this.Controls.Add(this.btnVerLst);
            this.Controls.Add(this.btnVerRdb);
            this.Controls.Add(this.btnVerChk);
            this.Controls.Add(this.btnVerTxt);
            this.Controls.Add(this.dtpFechaEjemplo);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.chlbEjemplo);
            this.Controls.Add(this.cmbEjemplo);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lstEjemplo);
            this.Controls.Add(this.grpEjemplo);
            this.Controls.Add(this.chkEjemplo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtEjemplo);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "FrmControles";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ejemplos de Controles";
            this.Load += new System.EventHandler(this.FrmControles_Load);
            this.grpEjemplo.ResumeLayout(false);
            this.grpEjemplo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmrEjemplo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtEjemplo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chkEjemplo;
        private System.Windows.Forms.GroupBox grpEjemplo;
        private System.Windows.Forms.RadioButton rdbEjemplo3;
        private System.Windows.Forms.RadioButton rdbEjemplo2;
        private System.Windows.Forms.RadioButton rdbEjemplo1;
        private System.Windows.Forms.ListBox lstEjemplo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbEjemplo;
        private System.Windows.Forms.CheckedListBox chlbEjemplo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtpFechaEjemplo;
        private System.Windows.Forms.Button btnVerTxt;
        private System.Windows.Forms.Button btnVerChk;
        private System.Windows.Forms.Button btnVerRdb;
        private System.Windows.Forms.Button btnVerLst;
        private System.Windows.Forms.Button btnVerCmb;
        private System.Windows.Forms.Button btnVerChlb;
        private System.Windows.Forms.Button btnVerDtp;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown nmrEjemplo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.MaskedTextBox mskEjemplo;
        private System.Windows.Forms.Button btnVerNmr;
        private System.Windows.Forms.Button btnVerMsk;
    }
}

