﻿using System;
using System.Drawing;
using System.Windows.Forms;
using CapaNegocio; // se deve instanciar la capa inferior luego de agregarla como referencia

namespace CapaVista
{
    public partial class frmPersonas : Form
    {
        //Instancio los objetos de las clases que utilizo en el form
        CN_Personas Pers = new CN_Personas();
        CV_Validar_Mail ValidaCorreo = new CV_Validar_Mail();

        public frmPersonas()
        {
            InitializeComponent();
        }

        private void frmPersonas_Load(object sender, EventArgs e)
        {
            //Acomodo el dataGridView a mi necesidad
            dgvPersonas.SelectionMode = DataGridViewSelectionMode.FullRowSelect; //Selecciona toda la fila
            dgvPersonas.ReadOnly = true; //hace que la grilla no se pueda editar
            dgvPersonas.MultiSelect = false; //desactiva la seleccion multiple
            dgvPersonas.AllowUserToAddRows = false; //desactiva la ultima fila 

            LlenarCombo(cmbLocalidad, "Localidades", "Id_Loc", "Localidad");
            LlenarCombo(cmbProvincia, "Provincias", "Id_Provincia", "Provincia");
            LlenarCombo(cmbTipoDoc, "TipoDoc", "Id", "Tipo");
            MostrarPersonas();
            dgvPersonas.Select();
            CV_Utiles.BloquearControles(this);
            CV_Botonera.btnFormularios(this, btnCancelar);
        }

        private void dgvPersonas_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            //Este evento pertenece al DataGridView, y ocurre cuando toma el foco o cambia de fila
            if (dgvPersonas.SelectedRows.Count > 0)
            {
                grpPersonas.Text = "Identificacion Persona Nº " + dgvPersonas.Rows[dgvPersonas.SelectedRows[0].Index].Cells["Id"].Value.ToString();
                txtApellido.Text = dgvPersonas.Rows[dgvPersonas.SelectedRows[0].Index].Cells["Apellido"].Value.ToString();
                txtNombres.Text = dgvPersonas.Rows[dgvPersonas.SelectedRows[0].Index].Cells["Nombre"].Value.ToString();
                cmbTipoDoc.SelectedValue = dgvPersonas.Rows[dgvPersonas.SelectedRows[0].Index].Cells["TipoDoc"].Value;
                txtNroDoc.Text = dgvPersonas.Rows[dgvPersonas.SelectedRows[0].Index].Cells["NroDoc"].Value.ToString();
                txtTelefono.Text = dgvPersonas.Rows[dgvPersonas.SelectedRows[0].Index].Cells["Telefono"].Value.ToString();
                txtCorreo.Text = dgvPersonas.Rows[dgvPersonas.SelectedRows[0].Index].Cells["Correo"].Value.ToString();
                txtCalle.Text = dgvPersonas.Rows[dgvPersonas.SelectedRows[0].Index].Cells["Calle"].Value.ToString();
                txtNro.Text = dgvPersonas.Rows[dgvPersonas.SelectedRows[0].Index].Cells["Nro"].Value.ToString();
                txtPiso.Text = dgvPersonas.Rows[dgvPersonas.SelectedRows[0].Index].Cells["Piso"].Value.ToString();
                txtDto.Text = dgvPersonas.Rows[dgvPersonas.SelectedRows[0].Index].Cells["Dto"].Value.ToString();
                cmbLocalidad.SelectedValue = dgvPersonas.Rows[dgvPersonas.SelectedRows[0].Index].Cells["IdLocalidad"].Value; ;
                cmbProvincia.SelectedValue = dgvPersonas.Rows[dgvPersonas.SelectedRows[0].Index].Cells["IdProvincia"].Value; ;
            }
        }

        #region BOTONES

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                PasarDatos();

                Pers.InsertarPersona();
                MostrarPersonas();

                CV_Botonera.btnFormularios(this, btnGuardaCambios);
                CV_Utiles.BloquearControles(this);
                dgvPersonas.Select();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se guardaron los datos por: \n" + ex);
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            CV_Utiles.DesbloquearControles(this);
            CV_Utiles.LimpiarControles(this);
            CV_Botonera.btnFormularios(this, btnAgregar);
            txtApellido.Select();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            CV_Botonera.btnFormularios(this, btnCancelar);
            CV_Utiles.BloquearControles(this);
            CV_Utiles.LimpiarControles(this);
            dgvPersonas.Select();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            CV_Botonera.btnFormularios(this, btnModificar);
            CV_Utiles.DesbloquearControles(this);
            txtApellido.Select();
        }

        private void btnGuardaCambios_Click(object sender, EventArgs e)
        {
            try
            {
                PasarDatos();

                Pers.ModificarPersona();

                MostrarPersonas();
                CV_Botonera.btnFormularios(this, btnGuardaCambios);
                CV_Utiles.BloquearControles(this);
                dgvPersonas.Select();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se guardaron los datos por: \n" + ex);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            var resultado = MessageBox.Show("esta seguro de ELIMINAR defilitivamente a la persona?",
                                                        "ELIMINAR PERSONA",
                                                        MessageBoxButtons.OKCancel,
                                                        MessageBoxIcon.Question);
            if (resultado == DialogResult.OK )
            {
                Pers.IdPersona = Convert.ToInt32(dgvPersonas.Rows[dgvPersonas.SelectedRows[0].Index].Cells["Id"].Value.ToString());
                Pers.EliminarPersona();
                MostrarPersonas();
                dgvPersonas.Select();
            }
        }

        #endregion


        #region Validaciones_Niveo_Formulario

        private void txtApellido_Validated(object sender, EventArgs e)
        {
            if (this.txtApellido.Text.Length == 0)
            {
                errorProvider1.SetError(this.txtApellido, "Debe tener un valor");
            }
            else
            {
                errorProvider1.SetError(this.txtApellido, "");
                errorProvider2.SetError(this.txtApellido, "  ");
            }
        }

        private void cmbTipoDoc_Validated(object sender, EventArgs e)
        {
            if (this.cmbTipoDoc.Text.Length == 0)
            {
                errorProvider1.SetError(this.cmbTipoDoc, "El campo Apellido no puede tener un valor vacio");
            }
            else
            {
                errorProvider1.SetError(this.cmbTipoDoc, "");
                errorProvider2.SetError(this.cmbTipoDoc, "CORRECTO");
            }
        }

        private void txtNombres_Validated(object sender, EventArgs e)
        {
            if (this.txtNombres.Text.Length == 0)
            {
                errorProvider1.SetError(this.txtNombres, "El campo Nombre no puede tener un valor vacio");
            }
            else
            {
                errorProvider1.SetError(this.txtNombres, "");
                errorProvider2.SetError(this.txtNombres, "CORRECTO");
            }
        }

        private void cmbLocalidad_Validated(object sender, EventArgs e)
        {
            if (this.cmbLocalidad.Text.Length == 0)
            {
                errorProvider1.SetError(this.cmbLocalidad, "Debe Seleccionar una Localidad");
            }
            else
            {
                errorProvider1.SetError(this.cmbLocalidad, "");
                errorProvider2.SetError(this.cmbLocalidad, "CORRECTO");
            }
        }

        private void cmbProvincia_Validated(object sender, EventArgs e)
        {
            if (this.cmbProvincia.Text.Length == 0)
            {
                errorProvider1.SetError(this.cmbProvincia, "Debe Seleccionar una Provincia");
            }
            else
            {
                errorProvider1.SetError(this.cmbProvincia, "");
                errorProvider2.SetError(this.cmbProvincia, "CORRECTO");
            }
        }

        private void txtCorreo_TextChanged(object sender, EventArgs e)
        {
            CV_Validar_Mail val = new CV_Validar_Mail();
            val.Correo = txtCorreo.Text;
            if (val.Valid() != true)
            {
                txtCorreo.ForeColor = Color.Red;
            }
            else
            {
                txtCorreo.ForeColor = Color.Black;
            }
        }
        #endregion

        #region METODOS

        private void MostrarPersonas()
        {
            CN_Personas Pers = new CN_Personas();
            dgvPersonas.DataSource = Pers.MostrarPersona();
        }

        private void LlenarCombo(ComboBox CMB, string NombreTabla, string CampoID, string CampoDescrip, string Condicion = "")
        {
            CN_LlenarCombos LC = new CN_LlenarCombos();

            LC.NomTabla = NombreTabla;
            LC.CampoId = CampoID;
            LC.CampoDescrip = CampoDescrip;
            LC.Condicion = Condicion;

            CMB.DataSource = LC.Cargar();
            CMB.DisplayMember = CampoDescrip;
            CMB.ValueMember = CampoID;
        }

        private void PasarDatos()
        {
            Pers.IdPersona = Convert.ToInt32(dgvPersonas.Rows[dgvPersonas.SelectedRows[0].Index].Cells["Id"].Value.ToString());
            Pers.Apellido = txtApellido.Text;
            Pers.Nombre = txtNombres.Text;
            if (cmbTipoDoc.SelectedItem == null)
            {
                Pers.TipoDoc = "0";
            }
            else
            {
                Pers.TipoDoc = cmbTipoDoc.SelectedValue.ToString();
            }
            Pers.NroDoc = txtNroDoc.Text;
            Pers.Telefono = txtTelefono.Text;
            Pers.Correo = txtCorreo.Text;
            Pers.Calle = txtCalle.Text;
            Pers.Nro = txtNro.Text;
            Pers.Piso = txtPiso.Text;
            Pers.Dto = txtDto.Text;
            if (cmbLocalidad.SelectedItem == null)
            {
                Pers.IdLocalidad = "0";
            }
            else
            {
                Pers.IdLocalidad = cmbLocalidad.SelectedValue.ToString();
            }
            if (cmbProvincia.SelectedItem == null)
            {
                Pers.IdProvincia = "0";
            }
            else
            {
                Pers.IdProvincia = cmbProvincia.SelectedValue.ToString();
            }
        }

        #endregion
    }
}