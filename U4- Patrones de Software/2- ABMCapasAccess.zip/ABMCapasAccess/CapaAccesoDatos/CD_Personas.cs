﻿using System.Data;
using System.Data.OleDb;

namespace CapaAccesoDatos
{
    public class CD_Personas
    {
        CD_Conexion conexion = new CD_Conexion();
        OleDbDataReader DR;
        DataTable DT = new DataTable();
        OleDbCommand comando = new OleDbCommand();

        #region ATRIBUTOS
        private int idpersona;
        private string apellido;
        private string nombre;
        private int tipodoc;
        private int nrodoc;
        private string telefono;
        private string correo;
        private string calle;
        private string nro;
        private string piso;
        private string dto;
        private int idlocalidad;
        private int idprovincia;
        #endregion

        #region PROPERTIES

        public int IdPersona
        {
            get => idpersona; //Expresion Lambda (Se suprime el Return y las llaves)
            set { idpersona = value; }
        }

        public string Apellido 
        {
            get => apellido; 
            set {apellido = value;}
        }

        public string Nombre
        {
            get => nombre;
            set {nombre = value;}
        }

        public int TipoDoc
        {
            get => tipodoc;
            set {tipodoc = value;}
        }

        public int NroDoc
        {
            get => nrodoc; 
            set {nrodoc = value;}
        }

        public string Telefono
        {
            get => telefono; 
            set {telefono = value;}
        }

        public string Correo
        {
            get => correo;
            set {correo = value;}
        }

        public string Calle
        {
            get => calle;
            set {calle = value;}
        }

        public string Nro
        {
            get => nro;
            set {nro = value;}
        }

        public string Piso
        {
            get => piso;
            set {piso = value;}
        }

        public string Dto
        {
            get => dto;
            set {dto = value;}
        }

        public int IdLocalidad
        {
            get => idlocalidad;
            set {idlocalidad = value;}
        }

        public int IdProvincia
        {
            get => idprovincia;
            set {idprovincia = value;}
        }
        #endregion

        #region METODOS

        public DataTable Mostrar()
        {
            CD_Conexion conexion = new CD_Conexion();
            comando.Connection = conexion.AbrirConexion();
            comando.CommandText = "Select * from Personas ";
            DR = comando.ExecuteReader();
            DT.Load(DR);
            conexion.CerrarConexion();
            return DT;
        }

        public void InsertarPersona()
        {
            string sSql = "INSERT INTO Personas " +
               "(Apellido, Nombre, TipoDoc, NroDoc, Telefono, Correo, Calle, Nro, Piso, Dto, IdLocalidad, IdProvincia) " +
                "values" +
                " ('" + apellido + "','" + nombre + "'," + tipodoc + "," + nrodoc +
                ",'" +telefono + "','" + correo + "','" + calle + "','" + nro +
                "','" + piso + "','" + dto + "'," + idlocalidad+ ", " + idprovincia + ")";
            Ejecutar(sSql);
        }

        public void ModificarPersona()
        {
            string sSql = "UPDATE Personas set " +
                "Apellido='" + apellido + "', Nombre='" + nombre  + "', TipoDoc =" + tipodoc  +
                ", NroDoc = " + nrodoc  + ", Telefono = '" + telefono + "', Correo = '" + correo  +
                "', Calle = '" + calle + "', Nro = '" + nro + "', Piso = '" + piso + "', Dto = '" + dto +
                "', IdLocalidad = " + idlocalidad + ", IdProvincia = " + idprovincia  +
                " WHERE Id =" + idpersona;
            Ejecutar(sSql);
        }

        public void EliminarPersona()
        {
            string sSql = "DELETE FROM Personas WHERE Id =" + idpersona;
            Ejecutar(sSql);
        }

        private void Ejecutar(string sSQL)
        {
            OleDbCommand cmd = new OleDbCommand(sSQL, conexion.AbrirConexion());
            cmd.ExecuteNonQuery();
            conexion.CerrarConexion();
        }
        #endregion
    }
}
