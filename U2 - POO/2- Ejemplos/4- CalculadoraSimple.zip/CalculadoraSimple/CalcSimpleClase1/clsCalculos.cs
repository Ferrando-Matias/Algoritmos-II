﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalcSimpleClase1
{
    class clsCalculos
    {
        private double Resultado; //Atributo

        //Metodo Suma, donde V1 es el primer valor y V2 es el segundo valor
        public double Suma(double V1, double V2)
        {
           return V1 + V2; 
        }

        //Metodo Resta, donde V1 es el primer valor y V2 es el segundo valor
        public double Resta(double V1, double V2)
        {
            return V1 - V2;
        }

        //Metodo Multiplicacion, donde V1 es el primer valor y V2 es el segundo valor
        public double Multiplicacion(double V1, double V2)
        {
            return V1 * V2;
        }

        //Metodo Division, donde V1 es el primer valor y V2 es el segundo valor
        public double Division(double V1, double V2)
        {
            return V1 / V2;
        }
    
        //Metodo Calcular, donde V1 es el primer valor y V2 es el segundo valor
        public double Calcular(string Signo, double V1, double V2)
        {
            switch (Signo)
            {
                case "+":
                    Resultado = V1 + V2;
                    break; 
                case "-":
                    Resultado = V1 - V2;
                    break; 
                case "*":
                    Resultado = V1 * V2;
                    break; 
                case "/":
                    Resultado = V1 / V2;
                    break; 
                default:
                    
                    break; 
            }
            return Resultado;
        }
    }
}
