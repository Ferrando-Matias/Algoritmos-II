﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
        

namespace CalcSimpleClase1
{
    public partial class CalcSimple : Form
    {
        public CalcSimple()
        {
            InitializeComponent();
        }
        
        private void CalcSimple_Load(object sender, EventArgs e)
        {
            txtValor1.Focus();
            this.ActiveControl = txtValor1; //manda el foco cuando no funciona "Focus"
        }

        private void btnSuma_Click(object sender, EventArgs e)
        {
            // double Val1, Val2; // Cuando las variables son del mismo tipo puedo declararlas juntas
            // Val1 = Convert.ToDouble(txtValor1.Text);
            // Val2 = Convert.ToDouble(txtValor2.Text);

            //Declaro e Inicializo las variables en un solo paso
            double Val1 =  Convert.ToDouble(txtValor1.Text);
            double Val2 = Convert.ToDouble(txtValor2.Text);

            //Instanciacion de la Clase clsCalculos que realizara los calculos matematicos
            clsCalculos clsCalc = new clsCalculos();

            // Paso los parametros necesarios al metodo Calcular de la clase y al mismo tiempo cargo
            // el resultado devuelto al Label
            //lblResultado.Text = clsCalc.Calcular("+", Val1, Val2).ToString();       //CUALQUIERA DE LOS 2 METODOS FUNCIONA PARA CONVERTIR DEL VALOR 
            lblResultado.Text = Convert.ToString(clsCalc.Calcular("+", Val1, Val2));  //DOUBLE A STRING, NECESARIO PARA CARGAR DENTRO DEL TEXTBOX
            textBox1.Text= Convert.ToString(clsCalc.Calcular("+", Val1, Val2));
          
        }

        private void btnResta_Click(object sender, EventArgs e)
        {
            var clsCalc = new clsCalculos();
            // lblResultado.Text = Convert.ToString(clsCalc.Calcular("-", Convert.ToDouble(txtValor1.Text), Convert.ToDouble(txtValor2.Text)));
            lblResultado.Text = Convert.ToString(clsCalc.Resta(Convert.ToDouble(txtValor1.Text), Convert.ToDouble(txtValor2.Text)));
            // puedo llamar al metodo calcular pasandole el signo, o llamar a un metodo especifico para resolver esta operacion
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            var clsCalc = new clsCalculos();
            lblResultado.Text = Convert.ToString(clsCalc.Calcular("*", Convert.ToDouble(txtValor1.Text), Convert.ToDouble(txtValor2.Text)));
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            var clsCalc = new clsCalculos();
            lblResultado.Text = Convert.ToString(clsCalc.Calcular("/", Convert.ToDouble(txtValor1.Text), Convert.ToDouble(txtValor2.Text)));
        }
    }
}
