﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConexionBD
{
    class OperacionesComunes
    {
        public void BloquearObjetos(Form FRM)
        {
            foreach (Control c in FRM.Controls)
            {
                if (c is TextBox)
                {
                    ((TextBox)c).Enabled  = false;
                }
                if (c is ComboBox)
                {
                    ((ComboBox)c).Enabled= false;
                }
                if (c is GroupBox | c is Panel)
                {
                    LC2(c);
                }
            }
        }

        private static void LC2(Control x)
        {
            foreach (Control h in x.Controls)
            {
                if (h is TextBox)
                {
                    ((TextBox)h).Enabled = false;
                }
                if (h is ComboBox)
                {
                    ((ComboBox)h).Enabled=false;
                }
            }
        }


        public void DesbloquearObjetos(Form FRM)
        {
            foreach (Control c in FRM.Controls)
            {
                if (c is TextBox)
                {
                    ((TextBox)c).Enabled = true;
                }
                if (c is ComboBox)
                {
                    ((ComboBox)c).Enabled = true;
                }
                if (c is GroupBox | c is Panel)
                {
                    DB2(c);
                }
            }
        }

        private static void DB2(Control x)
        {
            foreach (Control h in x.Controls)
            {
                if (h is TextBox)
                {
                    ((TextBox)h).Enabled = true;
                }
                if (h is ComboBox)
                {
                    ((ComboBox)h).Enabled = true;
                }
            }
        }

    }
}
