﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;
using System.Data.SqlClient;
using Utilitarios;


namespace ConexionBD
{
    public partial class frmABM_Alumnos : Form
    {
        ManejoBDAccess clsDB = new ManejoBDAccess(); //INSTANCIO LA CLASE DE LA CAPA DE ACCESO A DATOS
        OperacionesComunes OC = new OperacionesComunes();
        public frmABM_Alumnos()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //CARGO LOS COMBOBOX DEL FORMULARIO UTILIZANDO EL METODO "CARGARCMB"
            //DE LA CLASE ManejoDB INSTANCIADA AL COMIENZO DEL FORMULARIO CON LA VARIABLE clsDB
            clsDB.CargarCMB(cmbNacionalidad, "Nacionalidades", "Id_Nacionalidad", "Nacionalidad");
            //------------------------------------------------
            clsDB.CargarCMB(cmbTipoDoc, "TipoDoc", "Id_TipoDoc", "TipoDoc");
            //------------------------------------------------
            clsDB.CargarCMB(cmbLocalidad, "Localidades", "Id_Localidad", "Localidad");
            //------------------------------------------------
            clsDB.CargarCMB(cmbPartido, "Partidos", "Id_Partido", "Partido");
            //------------------------------------------------
            clsDB.CargarCMB(cmbProvincia, "Provincias", "Id_Provincia", "Provincia");
            //------------------------------------------------

            //Le paso por parametro la grilla al Metodo de la clase para que la cargue
            clsDB.CargarGrillaAlumnos(dtgAlumnos);
            
            
            //Oculto las columnas del DataGridView que no quiero que se vean
            this.dtgAlumnos.Columns["Id_Alumno"].Visible = false;
            this.dtgAlumnos.Columns["Alumnos.Id_Localidad"].Visible = false;
            this.dtgAlumnos.Columns["Localidades.Id_Localidad"].Visible = false;
            this.dtgAlumnos.Columns["Localidades.Id_Partido"].Visible = false;
            this.dtgAlumnos.Columns["Partidos.Id_Partido"].Visible = false;
            this.dtgAlumnos.Columns["Partidos.Id_Provincia"].Visible = false;
            this.dtgAlumnos.Columns["Partidos.Id_Provincia"].Visible = false;
            this.dtgAlumnos.Columns["tipo_Doc"].Visible = false;
            this.dtgAlumnos.Columns["Alumnos.Id_Nacionalidad"].Visible = false;
            this.dtgAlumnos.Columns["Id_TipoDoc"].Visible = false;
            this.dtgAlumnos.Columns["Nacionalidades.Id_Nacionalidad"].Visible = false;
            this.dtgAlumnos.Columns["Provincias.Id_Provincia"].Visible = false;
           
            OC.BloquearObjetos(this); //Bloqueo los controles
            dtgAlumnos.Focus(); //Mando el foco a la grilla
        }

        private void CargarAlumno()
        {   // Este procedimiento carga los datos de la grilla en los controles del formulario
            var row = dtgAlumnos.CurrentRow ;

            txtApellido.Text = Convert.ToString (dtgAlumnos["Apellido", dtgAlumnos.CurrentRow.Index].Value); 
            txtNombres.Text = row.Cells["Nombres"].Value.ToString();
            cmbTipoDoc.SelectedValue = Convert.ToInt32(dtgAlumnos[3, dtgAlumnos.CurrentRow.Index].Value); 
            txtNroDoc.Text = row.Cells[5].Value.ToString();
            txtCuil.Text = row.Cells[6].Value.ToString();
            cmbNacionalidad.SelectedValue = Convert.ToInt32(dtgAlumnos[7, dtgAlumnos.CurrentRow.Index].Value); 
            txtCalle.Text = row.Cells[9].Value.ToString();
            txtNro.Text = row.Cells[10].Value.ToString();
            txtPiso.Text = row.Cells[11].Value.ToString();
            txtDto.Text = row.Cells[12].Value.ToString();
            txtCP.Text = row.Cells["CodPost"].Value.ToString();
            cmbLocalidad.SelectedValue = Convert.ToInt32(dtgAlumnos[16, dtgAlumnos.CurrentRow.Index].Value);
            cmbPartido.SelectedValue = Convert.ToInt32(dtgAlumnos[19, dtgAlumnos.CurrentRow.Index].Value); 
            cmbProvincia.SelectedValue = Convert.ToInt32(dtgAlumnos[22, dtgAlumnos.CurrentRow.Index].Value);
        }
         
        private void cmbNacionalidad_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbNacionalidad.SelectedIndex  >= 0)
            {
                label16.Text = cmbNacionalidad.SelectedValue.ToString();
            }
        }

        private void dtgAlumnos_SelectionChanged(object sender, EventArgs e)
        {
            CargarAlumno();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Utilitarios.Utiles.LimpiarControles(this);
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            OC.DesbloquearObjetos(this);
            txtApellido.Focus();
            txtApellido.SelectAll();
        }

        private void txtNroDoc_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNroDoc_KeyPress(object sender, KeyPressEventArgs e)
        {
            Utilitarios.Utiles.ValidarNro(e);
        }
    }
}
