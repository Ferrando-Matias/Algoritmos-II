﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Windows.Forms;

namespace ConexionBD
{
    class ManejoBDAccess
    {
        private string CadenaConexionAccess = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|Escuela.accdb";

        private OleDbConnection CN;
        private OleDbDataAdapter DA = new OleDbDataAdapter();
        private OleDbCommand Comando;
        private DataTable dt; // = new DataTable();
        private DataSet DS; // = new DataSet();
      
        private void Conectar()
        {
            CN = new OleDbConnection(CadenaConexionAccess);
            CN.Open();
         }

        private void Desconectar()
        {
            CN.Close();
        }

        public void  CargarCMB(ComboBox CMB, string Tabla,string Campo1, string Campo2, String Condicion = "" )
        {
            string sSQL;
            if (Condicion == "")
            {
                sSQL = "SELECT " + Campo1 + ", " + Campo2 + " FROM " + Tabla + " ORDER BY " + Campo2;
            }
            else
            {
                sSQL = "SELECT " + Campo1 + ", " + Campo2 + " FROM " + Tabla + " Where  " + Condicion +" ORDER BY " + Campo2;
            }
            CMB.DataSource = Consultar(sSQL);
            CMB.DisplayMember = Campo2 ;
            CMB.ValueMember = Campo1;
         }

        public void CargarGrillaAlumnos(DataGridView DTG)
        {
            //Armo la consulta SQL
            string sSql = "SELECT Alumnos.Id_Alumno, Alumnos.Apellido, Alumnos.Nombres, Alumnos.tipo_Doc, TipoDoc.TipoDoc, Alumnos.Nro_Doc, Alumnos.CUIL, Alumnos.Id_Nacionalidad, Nacionalidades.Nacionalidad, Alumnos.Dir_Calle, Alumnos.Dir_Nro, Alumnos.Dir_Piso, Alumnos.Dir_Dto, Alumnos.Id_Localidad , TipoDoc.Id_TipoDoc, Nacionalidades.Id_Nacionalidad , Localidades.Id_Localidad , Localidades.Localidad, Localidades.CodPost, Localidades.Id_Partido , Partidos.Id_Partido , Partidos.Partido, Partidos.Id_Provincia , Provincias.Id_Provincia , Provincias.Provincia" +
                        " FROM((Provincias INNER JOIN Partidos ON Provincias.[Id_Provincia] = Partidos.[Id_Provincia]) INNER JOIN Localidades ON Partidos.[Id_Partido] = Localidades.[Id_Partido]) INNER JOIN(TipoDoc INNER JOIN (Nacionalidades INNER JOIN Alumnos ON Nacionalidades.[Id_Nacionalidad] = Alumnos.[Id_Nacionalidad]) ON TipoDoc.[Id_TipoDoc] = Alumnos.[tipo_Doc]) ON Localidades.[Id_Localidad] = Alumnos.[Id_Localidad]";
            DTG.DataSource = Consultar(sSql);
        }

        private DataTable Consultar(String sSQL)
        {
            try
            {
                Conectar();
                DA.Dispose();
                DA = new OleDbDataAdapter(sSQL, CN);
                dt = new DataTable();
                DA.Fill(dt);
                Desconectar();
            }
            catch (Exception e)
            {
                MessageBox.Show("Error en la conexion a la base de datos" + e, "ALERTA!",
                                            MessageBoxButtons.OK,
                                            MessageBoxIcon.Error,
                                            MessageBoxDefaultButton.Button1);
                dt.Dispose();
            }
            return dt;
        }

    }
}
