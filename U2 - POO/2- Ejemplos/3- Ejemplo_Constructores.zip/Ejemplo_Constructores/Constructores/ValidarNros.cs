﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructores
{
    /* 
     * La clase con modificador "static" (estatica) hace que ésta no tenga que 
     * ser instanciada en un objeto, sino que se acceda a ella directamente. 
     * Las clases estaticas solo pueden tener metodos estaticos, a diferencia
     * de las clases de instancia que pueden tener tanto metodos estaticos 
     * como de instancia.
     * Los metodos estaticos de las clases estaticas se llaman directamente,
     * no es necesario nombrar la clase previamente, siempre y cuando ésta
     * se encuentre dentro del mismo proyecto o se este importando el 
     * proyecto en el cual se encuentra.
     */
    public static class ValidarNros
    {
        /* El this en el parametro hace que tome lo que encuentra en la propiedad
         * seleccionada del control a evaluar al momento de llamarlo
          
         * Ejemplo: 
         *          txtdatos.Text.IsNumeric();
         *          cmbProvincias.Text.IsNumeric();
         */
        public static bool IsNumeric(this string texto)
        {
            /*
             * Lo que realiza este metodo es tratar de convertir un string que
             * recibe por parametro en decimal (tipo de dato numerico mas 
             * extenso), en caso de no poder convertirse daria una excepcion,
             * por lo que saltrá al "catch" de la estructura. En caso de 
             * poder convertir devolvera "true", y en caso contrario "false".
             */

            try
            {                
                decimal numero = Convert.ToDecimal(texto);
                return true;
            }
            catch (Exception)
            {
                return false;                
            }
        }
    }
}
