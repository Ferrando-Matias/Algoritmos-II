﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Constructores
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            Mensajes mjes;  // Creo un objeto llamado "mjes" del tipo "Mensajes" (clase)
            
            /*
              Con esta estructura selecciono, dependiendo de los datos cargados,
              a que Sobrecarga de Constructores voy a invocar
             */

            if (string.IsNullOrEmpty(txtDato1.Text.Trim()) && string.IsNullOrEmpty(txtDato2.Text.Trim()))
            /* Si los dos TextBox estan vacios invoco a la sobrecarga que no recibe parametros.
              
             * El metodo IsNullOrEmpty() de la clase string lo que realiza es comprobar 
             * si el control o atributo enviado por parametro es nulo o vacio. 
              
             * El metodo Trim() lo que realiza es quitar todos los espacios en blanco
             * del principio y final del string que recibe.
             */
            {
                mjes = new Mensajes();  // Instancio el objeto creado anteriormente llamando al constructor
            }
            else
            /* 
             * Si el dato del Textbox es numerico, invoco a la sobrecarga que
             * recibe un dato de tipo numerico entero
             */
            {
                if (string.IsNullOrEmpty(txtDato1.Text.Trim()))
                {
                    // solo dato 2
                    if (txtDato2.Text.IsNumeric())
                    {
                        //es numero
                        int Dato = Convert.ToInt32(txtDato2.Text);
                        mjes = new Mensajes(Dato);
                    }
                    else
                    {
                        //es string
                        string Dato = txtDato2.Text;
                        mjes = new Mensajes(Dato);
                    }
                }
                else if (string.IsNullOrEmpty(txtDato2.Text.Trim()))
                {
                    // solo dato 1
                    if (txtDato1.Text.IsNumeric())
                    {
                        //es numero
                        int Dato = Convert.ToInt32(txtDato1.Text);
                        mjes = new Mensajes(Dato);
                    }
                    else
                    {
                        //es string
                        string Dato = txtDato1.Text;
                        mjes = new Mensajes(Dato);
                    }

                }
                else    // ambos datos
                {                    
                    if (!txtDato1.Text.IsNumeric() && !txtDato2.Text.IsNumeric())
                    {
                        // ninguno es numerico
                        string Dato1 = txtDato1.Text;
                        string Dato2 = txtDato2.Text;
                        mjes = new Mensajes(Dato1, Dato2);
                    }
                    else
                    {
                        // alguno es numerico
                        if (txtDato1.Text.IsNumeric() && txtDato2.Text.IsNumeric())
                        {
                            // ambos son numericos
                            int Dato1 = Convert.ToInt32(txtDato1.Text);
                            int Dato2 = Convert.ToInt32(txtDato2.Text);
                            mjes = new Mensajes(Dato1, Dato2);
                        }
                        else if (txtDato1.Text.IsNumeric())
                        {
                            // el primero es numerico
                            int Dato1 = Convert.ToInt32(txtDato1.Text);
                            string Dato2 = txtDato2.Text;
                            mjes = new Mensajes(Dato1, Dato2);
                        }
                        else
                        {
                            // el segundo es numerico
                            string Dato1 = txtDato1.Text;
                            int Dato2 = Convert.ToInt32(txtDato2.Text);
                            mjes = new Mensajes(Dato1, Dato2);
                        }
                    }
                }
            }
        }
    }
}
