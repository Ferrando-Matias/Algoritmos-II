﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio17
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* Enunciado:
             * 17)	Muestra los números del 1 al 100
             */
            for (int i = 1; i < 101; i++)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
